__author__ = "Alex Li"
import os
import sys

print(sys.argv)
